from fastapi.testclient import TestClient
from src.main import app
import requests

client = TestClient(app)


# this test works offline (i.e. a mockup, no real end-to-end testing here)
# and checks if data can be read and written correctly via FastAPI
def test_mockup():
    # here we don't need to clear old sensor data since no server is running after the lifetime of the test

    # check if initially there is no sensor data
    response = client.get("/sensors/1/datapoints")
    assert response.status_code == 200
    assert response.json() == {"data": []}

    # activate the actuator
    response = client.post("/actuators/1", json={"value": 0.2})
    assert response.status_code == 200

    # check if correct sensor data has been produced
    response = client.get("/sensors/1/datapoints")
    assert response.status_code == 200
    assert response.json() == {"data": [0.4]}


# this test runs live, i.e. the server needs to be running
def test_live():
    read_url = "http://localhost:8000/sensors/1/datapoints"
    add_url = "http://localhost:8000/actuators/1"
    delete_url = "http://localhost:8000/sensors/1/datapoints"

    # clear all sensor data
    response = requests.delete(delete_url)
    assert response.status_code == 200

    # check if initially there is no sensor data
    response = requests.get(read_url)
    assert response.status_code == 200
    assert response.json() == {"data": []}

    # activate the actuator
    response = requests.post(add_url, json={"value": 1.0})
    assert response.status_code == 200

    # check if correct sensor data has been produced
    response = requests.get(read_url)
    assert response.status_code == 200
    assert response.json() == {"data": [2.0]}

    # clear all sensor data again
    response = requests.delete(delete_url)
    assert response.status_code == 200

    # check if the sensor data has disappeared
    response = requests.get(read_url)
    assert response.status_code == 200
    assert response.json() == {"data": []}
